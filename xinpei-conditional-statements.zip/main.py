#Python if statement:
a=7 
b=8 
if b > a: #=,<,><=,>=,!=
    print(True)
#Elif:
if a > b:
    print(True)
elif a < b:
    print(True)
#Else:
a=200 
b=33 
if b > a:
    print(True)
elif a==b:
    print(True)
else:
    print(False)
#short hand if:
if a > b:print(True)
#Short hand if else:
print(True)if a < b else print(False)
a=100 
b=100
print(True) if a > b else print("==")if a ==b else print(False)
#AND:
a=200 
b=44
c=500 
if a > b and c > a:
    print("Both conditions are true")
#OR:
if a > b or c < a:
    print("At least on of the statements is true")
#NOT:
if not b > a:
    print("a is greater than b")
#Nested if:
x=41
if x > 10:
    print(True)
    if x > 20:
        print(True)
    else:
        print(False)
#pass statement:
a=10 
b= 20 
if b > a:
    pass 
#While loop:
i=1
while i < 100:
    print(i)
    i +=1
i=1
while i < 10:
    print(i)
    if(i==5):
        break
    i +=1
#continue statement:
i=0 
while i < 10:
    i +=1 
    if i ==5:
        continue
    print(i)
#else statement:
i=1 
while i < 6:
    print(i)
    i+=1
else:
    print("i is no longer less than 6")
#For loops:
fruits=["apple","kiwi","cherry"]
for x in fruits:
    print(x)
for x in "cherry":
    print(x)
fruits=["apple","kiwi","cherry"]
for x in fruits:
    print(x)
    if x =="kiwi":
        break
fruits=["apple","kiwi","cherry"]
for x in fruits:
    if x=="kiwi":
     continue
    print(x)
fruits=["apple","kiwi","banana"]
colors=["red","green","yellow"]
for x in colors:
    for y in fruits:
        print(x,y)
#pass statement:
for x in[0,1,2,3]:
    pass
#def:
def my_function():
    print("hello")
my_function()
    
def my_function(name):
    print(name +" S")
my_function("amna")
my_function("xinpei")
    
    
    
    
    
    
    
    
        
        
        
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    