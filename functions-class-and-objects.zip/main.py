#Python functions:
#Create a function:
def my_function():
    print("hello today is a good weather")
#call a function:
my_function()
def weather():
    print("Today is a rainy day")
weather()
#Arguments:(information that can be passed into functions)
def person(fname):
    print(fname + " Sarfraz")
person("Amna")
person("Emi")
def person(fname,lname):
    print(fname + " " + lname)
person("Amna","Sarfraz")
def person(child3,child2,child1):
    print("The youngest child is "+child3)
person(child1="Emiley",child2="Emi",child3="Emilia")
def person(**kid):
    print("The kid's last name is "+kid["lname"])
person(fname="Toby",lname="John")
#Class:(like an object constructor or a blueprint for creating objects)
class MyClass:
    x=8 
print(MyClass)
class person:
    x="amNA"
print(person)
#object:
class weather:
    x="rain"
p1=weather()
print(p1.x)
class Person:
    def __init__(self,name,age):
        self.name="amna"
        self.age=23
p1=Person("name","age")
print(p1.name)
print(p1.age)












