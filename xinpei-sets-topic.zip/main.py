#SETS:
#storing multiple items in a single variable
#they are unordered,unchangeable,unindexed
#donot allow duplicate values, they ignore it
#represented with {} brackets
#Creating a set 
set1={"a","b","c","a"}
print(set1)
set2={True,"False",1}
print(set2)
#length of a set
set1={"a","b","c","a"}
print(len(set1))
print(type(set1))
set1={"a","b","c","a"}
set2={1,2,3}
set3={True,False}
set4={"a",3,False}
print(set4)
print(set2)
print(set3)
#Set constructor:
set_A=set(("a",3,False))
print(set_A)
#Access items:
theset={"car","bus","plane"}
for x in theset:
    print(x)
print("bike" in theset)
#Add set items
#add () method 
set1={1,2,3,4,5}
set1.add(9)
print(set1)
#update() method 
set1={"a","b","c"}
set2={1,2,3}
set1.update(set2)
print(set1)
#adding iterable using update() method 
set1={"a","b","c"}
list=["apple","kiwi"]
set1.update(list)
print(set1)
#Remove items
#remove()method 
set1={"a","b","c"}
set1.remove("b")
print(set1)
set1.discard("a")
print(set1)
set1={1,2,3,4,5}
set1.pop()
print(set1)
set1.clear()
print(set1)
#del set1
#print(set1)
#Loop sets:
#for Loop 
set_a={"apple","kiwi","d","l"}
for x in set_a:
    print(x)
#join sets :
#union () method 
set1={"a","b","c"}
set2={1,2,3}
set3=set1.union(set2)
print(set3)
#update()method:
set1.update(set2)
print(set1)
#intersection_update:
x={"apple","kiwi"}
y={"kiwi","c","h"}
x.intersection_update(y)
print(x)
x={"apple","kiwi"}
y={"kiwi","c","h"}
z=x.intersection(y)
print(z)
#symmetric_difference_update()
x={"apple","kiwi"}
y={"kiwi","c","h"}
x.symmetric_difference_update(y)
print(x)
x={"apple","kiwi"}
y={"kiwi","c","h"}
z=x.symmetric_difference(y)
print(z)
x={"apple","kiwi",True}
y={"kiwi","c","h",1,2}
z=x.symmetric_difference(y)
print(z)

















































































