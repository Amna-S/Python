#python arrays:
cars=["BMW","TOYOTA","KIA"]
print(cars)
#Accessing the array
x=cars[0]
print(x)
#Modify arrays
cars[1]="Honda"
print(cars)
#length of array
x=len(cars)
print(x)
#Looping arrays elements
for x in cars:
    print(x)
#Adding elements in array
cars=["BMW","TOYOTA","KIA"]
cars.append("Honda")
print(cars)
#Removing the arrays
cars.pop()
#Remove arrays
cars.remove("BMW")
print(cars)
cars.clear()
print(cars)
#Python classes
#Create a class:
class MyClass:
    x = 5
p1 = MyClass()
print(p1.x)
class MyClass:
    y=20
print(MyClass)
obj1=MyClass()
print(obj1.y)
#__init__() function
class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
obj1=Person("Harry",20)
print(obj1.name)
print(obj1.age)
class flower:
    def __init__(self,name,color):
        self.name=name
        self.color=color
obj1=flower("Rose","Red")
print(obj1)
#str()funtion:
class flower:
    def __init__(self,name,color):
        self.name=name
        self.color=color
    def __str__(self):
        return f"{self.name}({self.color})"
obj1=flower("Rose","Red")
print(obj1)
class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def myfunc(self):
        print("Hello my name is "+ self.name +" and my age is "+self.age)
obj1=Person("John","56")
obj1.myfunc()
#Modify object properties:
class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age
    def myfunc(self):
        print("Hello my name is "+ self.name +" my age is "+self.age)
p1=Person("Harry",78)
#del p1.age
#del p1
print(p1.age)
#pass statement:
class Person:
    pass
#inheritance:allows to define a class that inherits all methods and properites from another class.
#parent class:(base class)
#child class:(derived class)
class person:
    def __init__(self,name,lname):
        self.name=name
        self.lname=lname
    def printname(self):
        print(self.name+" "+self.lname)
x=person("amna","sheikh")
x.printname()




































