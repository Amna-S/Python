#Python Dictionaries
#ordered,changeable and allow duplicate values
#examples:
thisdict={
    "brand":"Ford",
    "model":"ABC",
    "year":2023,
    "year":2022
}
print(thisdict)
#dictionary length
thisdict={
    "brand":"Ford",
    "model":"ABC",
    "year":2023,
    "year":2022
}
print(len(thisdict))

mydictionary={
    "name":"Murat",
    "age":15,
    "height":5.56
}
print(mydictionary)
print(len(mydictionary))
#datatypes
mydictionary={
    "name":"Amna",
    "age":25,
    "height":5.5,
    "color":["purple","black","pink"],
    "fruits":("mango","kiwi","strawberry"),
    "vegetables":("potato","cucumber")
}
print(mydictionary)
print(len(mydictionary))
print(type(mydictionary))
#dict() constructor:
thisdict=dict(name="Murat",age=13,country="Turkiye")
print(thisdict)
#Access items
mydict={
    "brand":"Unze London",
    "article":76,
    "year":2023
}
x=mydict["article"]
print(x)
thedict={
    "brand":"Unze London",
    "article":76,
    "year":2023
}
x=thedict.get("article")
print(x)
#key()method 
thedict={
    "brand":"Unze London",
    "article":76,
    "year":2023
}
x=thedict.keys()
print(x)
car={
"brand":"Honda",
"model":"Sonata",
"year":2022
}
x=car.keys()
print(x)
car["color"]="white"
print(x)
#Values()method
car={
"brand":"Honda",
"model":"Sonata",
"year":2022
}
x=car.values()
print(x)
#items()method 
thisdict={
    "brand":"Toyota",
    "model":"Yaris",
    "year":2022
}
x=thisdict.items()
print(x)
#Checking if key exists:
thisdict={
    "brand":"Ford",
    "model":"Mustang",
    "year":2023
}
if "article" in thisdict:
    print(True)
#Changing values:
thisdict={
    "brand":"Ford",
    "model":"Mustang",
    "year":2023
}
thisdict["year"]=2022
print(thisdict)
#Update()method
thisdict={
    "brand":"Ford",
    "model":"Mustang",
    "year":2023
}
thisdict.update({"year":2018})
print(thisdict)
#Remove items
#pop()method
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
thedict.pop("article")
print(thedict)

thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
thedict.popitem()
print(thedict)
#clear()method
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
thedict.clear()
print(thedict)
#del keyword
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
del thedict["article"]
print(thedict)
#loop dictionaries:
#Print key names one by one:
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
for x in thedict:
    print(x)
    
#print values one by one:
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
for x in thedict:
    print(thedict[x])
#values()method:
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
for x in thedict.values():
    print(x)
#keys()method:
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
for x in thedict.keys():
    print(x)
#items()method:
thedict={
    "brand":"nike",
    "article":8987,
    "year":6050
}
for x,y in thedict.items():
    print(x,y)
#Copy dictionaries:
#copy()method
mydict={
     "brand":"Starbucks",
     "item":"coffee",
     "location":"street 12"
 }
b=mydict.copy()
print(b)
#dict()method 
mydict={
     "brand":"Starbucks",
     "item":"coffee",
     "location":"street 12"
 }
b=dict(mydict)
print(b)
#Nested dictionaries:
myfamily={
    "granparents":{
        "name":"Sheikh",
        "country":"Pakistan"
        },
        "parents":{
            "name":"Sarfraz",
            "country":"Pakistan"
            },
            "child":{
                "name":"Amna",
                "country":"Pakistan"
            }
        }
print(myfamily)
child1={
    "name":"Emily",
    "age":12
    }
child2={
    "name":"Emi",
    "age":19
    }
child3={
    "name":"Eva",
    "age":10
    }
myfamily={
    "child1":child1,
    "child2":child2,
    "child3":child3
    }
print(myfamily["child2"]["name"])
















    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
















































